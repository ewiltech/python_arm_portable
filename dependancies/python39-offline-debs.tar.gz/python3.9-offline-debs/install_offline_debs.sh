#!/bin/bash

# Folder with .deb files (defaults to current dir)
DEB_DIR=${1:-.}

echo "Installing all .deb packages in: $DEB_DIR"
echo "Starting offline install..."

cd "$DEB_DIR" || { echo "Failed to enter directory: $DEB_DIR"; exit 1; }

# Step 1: Try to install all .deb files with dpkg
dpkg -i *.deb

# Step 2: Fix any missing dependencies
echo "Fixing any missing dependencies..."
apt-get install -f -y

# Optional: Show any broken packages
echo "Checking for broken packages..."
dpkg --audit

echo "Offline installation complete!"

